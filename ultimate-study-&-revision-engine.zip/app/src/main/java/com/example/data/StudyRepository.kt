package com.example.data

import kotlinx.coroutines.flow.Flow

class StudyRepository(private val studyDao: StudyDao) {

    fun getOverviewForDate(date: String): Flow<DailyOverview?> {
        return studyDao.getOverviewForDate(date)
    }

    suspend fun insertOverview(overview: DailyOverview) {
        studyDao.insertOverview(overview)
    }

    fun getSubjectTrackersForDate(date: String): Flow<List<SubjectTracker>> {
        return studyDao.getSubjectTrackersForDate(date)
    }

    suspend fun insertSubjectTracker(tracker: SubjectTracker) {
        studyDao.insertSubjectTracker(tracker)
    }

    suspend fun updateSubjectTracker(tracker: SubjectTracker) {
        studyDao.updateSubjectTracker(tracker)
    }

    suspend fun deleteSubjectTracker(tracker: SubjectTracker) {
        studyDao.deleteSubjectTracker(tracker)
    }

    suspend fun deleteSubjectTrackerById(id: Int) {
        studyDao.deleteSubjectTrackerById(id)
    }

    fun getTodoItemsForDate(date: String): Flow<List<TodoItem>> {
        return studyDao.getTodoItemsForDate(date)
    }

    suspend fun insertTodoItem(item: TodoItem) {
        studyDao.insertTodoItem(item)
    }

    suspend fun updateTodoItem(item: TodoItem) {
        studyDao.updateTodoItem(item)
    }

    suspend fun deleteTodoItem(item: TodoItem) {
        studyDao.deleteTodoItem(item)
    }

    suspend fun deleteTodoItemById(id: Int) {
        studyDao.deleteTodoItemById(id)
    }

    fun getTimeSlotsForDate(date: String): Flow<List<TimeSlot>> {
        return studyDao.getTimeSlotsForDate(date)
    }

    suspend fun insertTimeSlot(slot: TimeSlot) {
        studyDao.insertTimeSlot(slot)
    }

    suspend fun deleteTimeSlot(slot: TimeSlot) {
        studyDao.deleteTimeSlot(slot)
    }

    suspend fun deleteTimeSlotById(id: Int) {
        studyDao.deleteTimeSlotById(id)
    }

    fun getHabitsForWeek(weekStartDate: String): Flow<List<WeekHabit>> {
        return studyDao.getHabitsForWeek(weekStartDate)
    }

    suspend fun insertWeekHabit(habit: WeekHabit) {
        studyDao.insertWeekHabit(habit)
    }

    suspend fun updateWeekHabit(habit: WeekHabit) {
        studyDao.updateWeekHabit(habit)
    }

    fun getSkippedTopics(): Flow<List<SkippedTopic>> {
        return studyDao.getSkippedTopics()
    }

    suspend fun insertSkippedTopic(topic: SkippedTopic) {
        studyDao.insertSkippedTopic(topic)
    }

    suspend fun updateSkippedTopic(topic: SkippedTopic) {
        studyDao.updateSkippedTopic(topic)
    }

    suspend fun deleteSkippedTopic(topic: SkippedTopic) {
        studyDao.deleteSkippedTopic(topic)
    }

    suspend fun deleteSkippedTopicById(id: Int) {
        studyDao.deleteSkippedTopicById(id)
    }

    fun getSkippedQuestions(): Flow<List<SkippedQuestion>> {
        return studyDao.getSkippedQuestions()
    }

    suspend fun insertSkippedQuestion(question: SkippedQuestion) {
        studyDao.insertSkippedQuestion(question)
    }

    suspend fun updateSkippedQuestion(question: SkippedQuestion) {
        studyDao.updateSkippedQuestion(question)
    }

    suspend fun deleteSkippedQuestion(question: SkippedQuestion) {
        studyDao.deleteSkippedQuestion(question)
    }

    suspend fun deleteSkippedQuestionById(id: Int) {
        studyDao.deleteSkippedQuestionById(id)
    }
}
