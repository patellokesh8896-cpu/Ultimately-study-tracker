package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "daily_overviews")
data class DailyOverview(
    @PrimaryKey val date: String, // format: YYYY-MM-DD
    val dayName: String = "",
    val dayCount: Int = 0,
    val totalStudyHours: Double = 0.0,
    val focusLevel: Int = 3, // 1 to 5 stars
    val pomodoroCount: Int = 0, // Finished pomodoros
    // Well-being
    val targetScreenTime: Double = 0.0,
    val actualScreenTime: Double = 0.0,
    val distractionTrigger: String = "",
    val interventionStrategy: String = "",
    // Reflection
    val happyToday: String = "",
    val bestThingsToday: String = "",
    val worstThingsToday: String = ""
)

@Entity(tableName = "subject_trackers")
data class SubjectTracker(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val date: String, // foreign-key-like YYYY-MM-DD
    val subjectName: String,
    val isClass: Boolean = false,
    val isLecture: Boolean = false,
    val isActiveRecall: Boolean = false,
    val isNotes: Boolean = false,
    val isShortNotes: Boolean = false,
    val isRevision: Boolean = false,
    val nextRevDate: String = "", // formatted date (or YYYY-MM-DD)
    val numQs: Int = 0,
    val correct: Int = 0,
    val incorrect: Int = 0,
    val skipped: Int = 0,
    // Spaced repetition rings
    val r3: Boolean = false,
    val r7: Boolean = false,
    val r15: Boolean = false,
    val r30: Boolean = false,
    val r60: Boolean = false
)

@Entity(tableName = "todo_items")
data class TodoItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val date: String,
    val title: String,
    val isCompleted: Boolean = false
)

@Entity(tableName = "time_slots")
data class TimeSlot(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val date: String,
    val time: String,
    val whatWasDone: String
)

@Entity(tableName = "week_habits")
data class WeekHabit(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val weekStartDate: String, // YYYY-MM-DD of Monday
    val dayOfWeek: Int, // 1 (Mon) to 7 (Sun)
    val habitName: String, // "Wake Early", "Morning Warm Water", "Exercise", "Current Topic", "Revision"
    val isCompleted: Boolean = false
)

@Entity(tableName = "skipped_topics")
data class SkippedTopic(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val subject: String,
    val topic: String,
    val plannedDate: String = "",
    val status: String = "Pending" // Pending / Scheduled / Done
)

@Entity(tableName = "skipped_questions")
data class SkippedQuestion(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val subject: String,
    val topic: String,
    val qNo: String,
    val reattemptDate: String = "",
    val isDone: Boolean = false
)
