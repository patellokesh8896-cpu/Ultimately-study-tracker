package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface StudyDao {

    // --- Daily Overview ---
    @Query("SELECT * FROM daily_overviews WHERE date = :date LIMIT 1")
    fun getOverviewForDate(date: String): Flow<DailyOverview?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOverview(overview: DailyOverview)

    // --- Subject Trackers ---
    @Query("SELECT * FROM subject_trackers WHERE date = :date")
    fun getSubjectTrackersForDate(date: String): Flow<List<SubjectTracker>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSubjectTracker(tracker: SubjectTracker)

    @Update
    suspend fun updateSubjectTracker(tracker: SubjectTracker)

    @Delete
    suspend fun deleteSubjectTracker(tracker: SubjectTracker)

    @Query("DELETE FROM subject_trackers WHERE id = :id")
    suspend fun deleteSubjectTrackerById(id: Int)

    // --- Todo Items ---
    @Query("SELECT * FROM todo_items WHERE date = :date")
    fun getTodoItemsForDate(date: String): Flow<List<TodoItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTodoItem(item: TodoItem)

    @Update
    suspend fun updateTodoItem(item: TodoItem)

    @Delete
    suspend fun deleteTodoItem(item: TodoItem)

    @Query("DELETE FROM todo_items WHERE id = :id")
    suspend fun deleteTodoItemById(id: Int)

    // --- Time Slots ---
    @Query("SELECT * FROM time_slots WHERE date = :date ORDER BY id ASC")
    fun getTimeSlotsForDate(date: String): Flow<List<TimeSlot>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTimeSlot(slot: TimeSlot)

    @Delete
    suspend fun deleteTimeSlot(slot: TimeSlot)

    @Query("DELETE FROM time_slots WHERE id = :id")
    suspend fun deleteTimeSlotById(id: Int)

    // --- Weekly Habits ---
    @Query("SELECT * FROM week_habits WHERE weekStartDate = :weekStartDate")
    fun getHabitsForWeek(weekStartDate: String): Flow<List<WeekHabit>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWeekHabit(habit: WeekHabit)

    @Update
    suspend fun updateWeekHabit(habit: WeekHabit)

    // --- Skipped Topics ---
    @Query("SELECT * FROM skipped_topics ORDER BY id DESC")
    fun getSkippedTopics(): Flow<List<SkippedTopic>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSkippedTopic(topic: SkippedTopic)

    @Update
    suspend fun updateSkippedTopic(topic: SkippedTopic)

    @Delete
    suspend fun deleteSkippedTopic(topic: SkippedTopic)

    @Query("DELETE FROM skipped_topics WHERE id = :id")
    suspend fun deleteSkippedTopicById(id: Int)

    // --- Skipped Questions ---
    @Query("SELECT * FROM skipped_questions ORDER BY id DESC")
    fun getSkippedQuestions(): Flow<List<SkippedQuestion>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSkippedQuestion(question: SkippedQuestion)

    @Update
    suspend fun updateSkippedQuestion(question: SkippedQuestion)

    @Delete
    suspend fun deleteSkippedQuestion(question: SkippedQuestion)

    @Query("DELETE FROM skipped_questions WHERE id = :id")
    suspend fun deleteSkippedQuestionById(id: Int)
}
