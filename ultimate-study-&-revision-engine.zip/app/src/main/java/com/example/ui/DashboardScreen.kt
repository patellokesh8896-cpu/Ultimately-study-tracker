package com.example.ui

import android.app.DatePickerDialog
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.*
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import kotlin.random.Random

// Confetti model
data class ConfettiParticle(
    var x: Float,
    var y: Float,
    val speedX: Float,
    val speedY: Float,
    val color: Color,
    val size: Float,
    var rotation: Float,
    val rotationSpeed: Float
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: StudyTrackerViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // ViewModel variables
    val selectedDate by viewModel.selectedDate.collectAsStateWithLifecycle()
    val isLandscape by viewModel.isLandscapeLayout.collectAsStateWithLifecycle()
    val isDarkMode by viewModel.isDarkMode.collectAsStateWithLifecycle()

    val overview by viewModel.currentOverview.collectAsStateWithLifecycle()
    val subjectTrackers by viewModel.currentSubjectTrackers.collectAsStateWithLifecycle()
    val todoItems by viewModel.currentTodoItems.collectAsStateWithLifecycle()
    val timeSlots by viewModel.currentTimeSlots.collectAsStateWithLifecycle()
    val habits by viewModel.currentHabits.collectAsStateWithLifecycle()

    val skippedTopics by viewModel.skippedTopics.collectAsStateWithLifecycle()
    val skippedQuestions by viewModel.skippedQuestions.collectAsStateWithLifecycle()

    // Pomodoro Timer state
    val pomodoroSecondsLeft by viewModel.pomodoroSecondsLeft.collectAsStateWithLifecycle()
    val isPomodoroRunning by viewModel.isPomodoroRunning.collectAsStateWithLifecycle()
    val pomodoroMode by viewModel.pomodoroMode.collectAsStateWithLifecycle()

    // UI Local Dialog triggers
    var showAddSubjectDialog by remember { mutableStateOf(false) }
    var showAddTodoDialog by remember { mutableStateOf(false) }
    var showAddTimeSlotDialog by remember { mutableStateOf(false) }
    var showAddSkippedTopicDialog by remember { mutableStateOf(false) }
    var showAddSkippedQuestionDialog by remember { mutableStateOf(false) }

    // Tab Selection for "Focus Tab Layout"
    var activeTab by remember { mutableIntStateOf(0) } // 0: Daily Engine, 1: Habits & Reflection

    // Calculate Completion Progress
    val progressMetrics = remember(subjectTrackers, todoItems) {
        var total = 0
        var completed = 0

        subjectTrackers.forEach { tracker ->
            // 6 baseline columns
            total += 6
            if (tracker.isClass) completed++
            if (tracker.isLecture) completed++
            if (tracker.isActiveRecall) completed++
            if (tracker.isNotes) completed++
            if (tracker.isShortNotes) completed++
            if (tracker.isRevision) completed++

            // 5 Spaced Repetition Rings
            total += 5
            if (tracker.r3) completed++
            if (tracker.r7) completed++
            if (tracker.r15) completed++
            if (tracker.r30) completed++
            if (tracker.r60) completed++
        }

        todoItems.forEach { _ ->
            total++
        }
        todoItems.forEach { item ->
            if (item.isCompleted) completed++
        }

        val percentage = if (total > 0) completed.toFloat() / total else 0.0f
        Pair(percentage, "$completed/$total")
    }

    val progress = progressMetrics.first
    val progressLabel = progressMetrics.second

    // Keep track of confetti trigger
    var hasTriggeredConfettiForToday by remember { mutableStateOf(false) }
    val confettiParticles = remember { mutableStateListOf<ConfettiParticle>() }

    // Reset confetti trigger when date changes
    LaunchedEffect(selectedDate) {
        hasTriggeredConfettiForToday = progress >= 1.0f
    }

    // Confetti physics loop
    LaunchedEffect(progress) {
        if (progress >= 1.0f && !hasTriggeredConfettiForToday) {
            hasTriggeredConfettiForToday = true
            // Launch confetti particles
            val colors = listOf(DarkPrimary, DarkSecondary, DarkTertiary, AccentGold, Color.Cyan, Color.Magenta)
            val random = Random(System.currentTimeMillis())
            repeat(120) {
                confettiParticles.add(
                    ConfettiParticle(
                        x = random.nextFloat() * 1000f,
                        y = -50f,
                        speedX = (random.nextFloat() * 12f) - 6f,
                        speedY = random.nextFloat() * 15f + 10f,
                        color = colors[random.nextInt(colors.size)],
                        size = random.nextFloat() * 20f + 10f,
                        rotation = random.nextFloat() * 360f,
                        rotationSpeed = (random.nextFloat() * 10f) - 5f
                    )
                )
            }
        }
    }

    LaunchedEffect(confettiParticles.size) {
        if (confettiParticles.isNotEmpty()) {
            while (confettiParticles.isNotEmpty()) {
                delay(16)
                val toRemove = mutableListOf<ConfettiParticle>()
                for (i in confettiParticles.indices) {
                    val p = confettiParticles[i]
                    p.y += p.speedY
                    p.x += p.speedX
                    p.rotation += p.rotationSpeed
                    if (p.y > 2500f) {
                        toRemove.add(p)
                    }
                }
                confettiParticles.removeAll(toRemove)
            }
        }
    }

    // Detect Spaced Repitition Due Dates & Notifications
    // Sticky notification list
    val dueRevisions = remember(subjectTrackers, selectedDate) {
        subjectTrackers.filter { tracker ->
            tracker.nextRevDate.isNotEmpty() && tracker.nextRevDate == selectedDate
        }
    }

    MyApplicationTheme(darkTheme = isDarkMode) {
        Scaffold(
            topBar = {
                Column {
                    // Title Bar / Sub Header
                    TopAppBar(
                        title = {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Rounded.Dashboard,
                                        contentDescription = "App Icon",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.padding(end = 8.dp)
                                    )
                                    Text(
                                        text = "Ultimate Study Engine",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        color = MaterialTheme.colorScheme.onBackground
                                    )
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    // Layout Toggle Button
                                    IconButton(
                                        onClick = { viewModel.toggleLayout() },
                                        modifier = Modifier.testTag("toggle_layout_button")
                                    ) {
                                        Icon(
                                            imageVector = if (isLandscape) Icons.Rounded.Book else Icons.Rounded.Smartphone,
                                            contentDescription = "Toggle Layout",
                                            tint = MaterialTheme.colorScheme.onBackground
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(4.dp))

                                    // Dark/Light Theme Toggle
                                    IconButton(
                                        onClick = { viewModel.toggleTheme() },
                                        modifier = Modifier.testTag("toggle_theme_button")
                                    ) {
                                        Icon(
                                            imageVector = if (isDarkMode) Icons.Rounded.LightMode else Icons.Rounded.DarkMode,
                                            contentDescription = "Toggle Dark Mode",
                                            tint = MaterialTheme.colorScheme.onBackground
                                        )
                                    }
                                }
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.background,
                            titleContentColor = MaterialTheme.colorScheme.onBackground
                        )
                    )

                    // Real-time Gradient Progress Bar
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        val animatedProgress by animateFloatAsState(
                            targetValue = progress,
                            animationSpec = spring(dampingRatio = Spring.DampingRatioLowBouncy),
                            label = "ProgressBarAnimation"
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .fillMaxWidth(animatedProgress)
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(
                                            MaterialTheme.colorScheme.secondary,
                                            MaterialTheme.colorScheme.primary,
                                            MaterialTheme.colorScheme.tertiary
                                        )
                                    )
                                )
                        )
                    }

                    // Sticky Notification Banner if revision is due today
                    if (dueRevisions.isNotEmpty()) {
                        val dueSubjects = dueRevisions.joinToString(", ") { it.subjectName }
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = AccentRed.copy(alpha = 0.15f),
                                contentColor = AccentRed
                            ),
                            shape = RectangleShape,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    // Highlight revision centers
                                }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Warning,
                                    contentDescription = "Warning Notification",
                                    tint = AccentRed,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "⚠️ Attention Lokesh: ${dueRevisions.size} Revision${if (dueRevisions.size > 1) "s" else ""} Due for [$dueSubjects] Today!",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            },
            floatingActionButton = {
                // Floating Pomodoro Timer
                FloatingPomodoroWidget(
                    secondsLeft = pomodoroSecondsLeft,
                    isRunning = isPomodoroRunning,
                    mode = pomodoroMode,
                    onToggle = { viewModel.togglePomodoro() },
                    onReset = { viewModel.resetPomodoro() },
                    onSetMode = { mode -> viewModel.setPomodoroMode(mode) },
                    pomodoroCount = overview.pomodoroCount
                )
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { innerPadding ->
            Box(
                modifier = modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    // Custom confetti particle overlay
                    .drawBehind {
                        confettiParticles.forEach { particle ->
                            rotate(particle.rotation, Offset(particle.x, particle.y)) {
                                drawRect(
                                    color = particle.color,
                                    topLeft = Offset(
                                        particle.x - particle.size / 2,
                                        particle.y - particle.size / 2
                                    ),
                                    size = androidx.compose.ui.geometry.Size(
                                        particle.size,
                                        particle.size
                                    )
                                )
                            }
                        }
                    }
            ) {
                // Main screen view content: Dual View
                if (isLandscape) {
                    // Landscape Book Layout: Side-by-side Page 1 and Page 2
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Left Page: 1 Daily Engine (Anatomy Table, Todo, Logger)
                        Box(
                            modifier = Modifier
                                .weight(1.1f)
                                .fillMaxHeight()
                                .border(
                                    1.dp,
                                    MaterialTheme.colorScheme.surfaceVariant,
                                    RoundedCornerShape(12.dp)
                                )
                                .background(
                                    MaterialTheme.colorScheme.surface.copy(alpha = 0.3f),
                                    RoundedCornerShape(12.dp)
                                )
                                .clip(RoundedCornerShape(12.dp))
                        ) {
                            Page1DailyEngine(
                                viewModel = viewModel,
                                selectedDate = selectedDate,
                                overview = overview,
                                subjectTrackers = subjectTrackers,
                                dueRevisions = dueRevisions,
                                todoItems = todoItems,
                                timeSlots = timeSlots,
                                progressLabel = progressLabel,
                                progressFraction = progress,
                                onAddSubjectClick = { showAddSubjectDialog = true },
                                onAddTodoClick = { showAddTodoDialog = true },
                                onAddTimeSlotClick = { showAddTimeSlotDialog = true }
                            )
                        }

                        // Right Page: Wellbeing, Habits & Reflection
                        Box(
                            modifier = Modifier
                                .weight(0.9f)
                                .fillMaxHeight()
                                .border(
                                    1.dp,
                                    MaterialTheme.colorScheme.surfaceVariant,
                                    RoundedCornerShape(12.dp)
                                )
                                .background(
                                    MaterialTheme.colorScheme.surface.copy(alpha = 0.3f),
                                    RoundedCornerShape(12.dp)
                                )
                                .clip(RoundedCornerShape(12.dp))
                        ) {
                            Page2WellbeingHabitsReflection(
                                viewModel = viewModel,
                                selectedDate = selectedDate,
                                overview = overview,
                                habits = habits,
                                skippedTopics = skippedTopics,
                                skippedQuestions = skippedQuestions,
                                onAddSkippedTopicClick = { showAddSkippedTopicDialog = true },
                                onAddSkippedQuestionClick = { showAddSkippedQuestionDialog = true }
                            )
                        }
                    }
                } else {
                    // Focus Tab Layout: Show Tabs and render corresponding page
                    Column(modifier = Modifier.fillMaxSize()) {
                        // Tab selectors
                        TabRow(
                            selectedTabIndex = activeTab,
                            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.5f),
                            contentColor = MaterialTheme.colorScheme.primary,
                            indicator = { tabPositions ->
                                TabRowDefaults.SecondaryIndicator(
                                    modifier = Modifier.tabIndicatorOffset(tabPositions[activeTab]),
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        ) {
                            Tab(
                                selected = activeTab == 0,
                                onClick = { activeTab = 0 },
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Rounded.OfflineBolt,
                                            contentDescription = "Daily Engine Tab"
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            "Daily Engine",
                                            fontWeight = if (activeTab == 0) FontWeight.Bold else FontWeight.Normal
                                        )
                                    }
                                }
                            )
                            Tab(
                                selected = activeTab == 1,
                                onClick = { activeTab = 1 },
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Rounded.SelfImprovement,
                                            contentDescription = "Habits Reflex Tab"
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            "Habits & Reflection",
                                            fontWeight = if (activeTab == 1) FontWeight.Bold else FontWeight.Normal
                                        )
                                    }
                                }
                            )
                        }

                        // Display active tab view
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                        ) {
                            if (activeTab == 0) {
                                Page1DailyEngine(
                                    viewModel = viewModel,
                                    selectedDate = selectedDate,
                                    overview = overview,
                                    subjectTrackers = subjectTrackers,
                                    dueRevisions = dueRevisions,
                                    todoItems = todoItems,
                                    timeSlots = timeSlots,
                                    progressLabel = progressLabel,
                                    progressFraction = progress,
                                    onAddSubjectClick = { showAddSubjectDialog = true },
                                    onAddTodoClick = { showAddTodoDialog = true },
                                    onAddTimeSlotClick = { showAddTimeSlotDialog = true },
                                    isSinglePageMode = true
                                )
                            } else {
                                Page2WellbeingHabitsReflection(
                                    viewModel = viewModel,
                                    selectedDate = selectedDate,
                                    overview = overview,
                                    habits = habits,
                                    skippedTopics = skippedTopics,
                                    skippedQuestions = skippedQuestions,
                                    onAddSkippedTopicClick = { showAddSkippedTopicDialog = true },
                                    onAddSkippedQuestionClick = { showAddSkippedQuestionDialog = true },
                                    isSinglePageMode = true
                                )
                            }
                        }
                    }
                }
            }
        }

        // --- Dialog Declarations ---

        if (showAddSubjectDialog) {
            AddSubjectDialog(
                onDismiss = { showAddSubjectDialog = false },
                onAdd = { label ->
                    viewModel.addCustomSubject(label)
                    showAddSubjectDialog = false
                }
            )
        }

        if (showAddTodoDialog) {
            AddTodoDialog(
                onDismiss = { showAddTodoDialog = false },
                onAdd = { desc ->
                    viewModel.addTodoItem(desc)
                    showAddTodoDialog = false
                }
            )
        }

        if (showAddTimeSlotDialog) {
            AddTimeSlotDialog(
                onDismiss = { showAddTimeSlotDialog = false },
                onAdd = { time, detail ->
                    viewModel.addTimeSlot(time, detail)
                    showAddTimeSlotDialog = false
                }
            )
        }

        if (showAddSkippedTopicDialog) {
            AddSkippedTopicDialog(
                onDismiss = { showAddSkippedTopicDialog = false },
                onAdd = { subj, topic, date ->
                    viewModel.addSkippedTopic(subj, topic, date)
                    showAddSkippedTopicDialog = false
                }
            )
        }

        if (showAddSkippedQuestionDialog) {
            AddSkippedQuestionDialog(
                onDismiss = { showAddSkippedQuestionDialog = false },
                onAdd = { subj, topic, qNo, date ->
                    viewModel.addSkippedQuestion(subj, topic, qNo, date)
                    showAddSkippedQuestionDialog = false
                }
            )
        }
    }
}

// ==========================================
// COLUMN/PAGE 1: CORE STUDY ENGINE
// ==========================================
@Composable
fun Page1DailyEngine(
    viewModel: StudyTrackerViewModel,
    selectedDate: String,
    overview: DailyOverview,
    subjectTrackers: List<SubjectTracker>,
    dueRevisions: List<SubjectTracker>,
    todoItems: List<TodoItem>,
    timeSlots: List<TimeSlot>,
    progressLabel: String,
    progressFraction: Float,
    onAddSubjectClick: () -> Unit,
    onAddTodoClick: () -> Unit,
    onAddTimeSlotClick: () -> Unit,
    modifier: Modifier = Modifier,
    isSinglePageMode: Boolean = false
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Daily Overview Header Box
        item {
            DailyOverviewHeaderCard(
                selectedDate = selectedDate,
                overview = overview,
                progressLabel = progressLabel,
                progressFraction = progressFraction,
                viewModel = viewModel
            )
        }

        // Spaced Repetition Reminders (Alarm widget sidebar in column)
        item {
            RevisionAlarmCenterWidget(
                selectedDate = selectedDate,
                subjectTrackers = subjectTrackers
            )
        }

        // Dynamic Subjects Execution Table
        item {
            SubjectsTrackerTableCard(
                selectedDate = selectedDate,
                subjectTrackers = subjectTrackers,
                onAddSubjectClick = onAddSubjectClick,
                dueRevisions = dueRevisions,
                onUpdate = { viewModel.updateSubjectTracker(it) },
                onDelete = { viewModel.deleteSubjectTracker(it) }
            )
        }

        // Interactive To-Do List & Time logger side-by-side or stacked
        item {
            ToDoAndLoggerSection(
                todoItems = todoItems,
                timeSlots = timeSlots,
                onAddTodoClick = onAddTodoClick,
                onAddTimeSlotClick = onAddTimeSlotClick,
                onToggleTodo = { viewModel.toggleTodoItem(it) },
                onDeleteTodo = { viewModel.deleteTodoItem(it) },
                onDeleteTimeSlot = { viewModel.deleteTimeSlot(it) }
            )
        }

        // Performance insights diagnostic box
        item {
            PerformanceRatingInsightsFooter(
                subjectTrackers = subjectTrackers,
                progressFraction = progressFraction
            )
        }
    }
}

// ==========================================
// COLUMN/PAGE 2: WELLBEING, HABITS & REFLECTIONS
// ==========================================
@Composable
fun Page2WellbeingHabitsReflection(
    viewModel: StudyTrackerViewModel,
    selectedDate: String,
    overview: DailyOverview,
    habits: List<WeekHabit>,
    skippedTopics: List<SkippedTopic>,
    skippedQuestions: List<SkippedQuestion>,
    onAddSkippedTopicClick: () -> Unit,
    onAddSkippedQuestionClick: () -> Unit,
    modifier: Modifier = Modifier,
    isSinglePageMode: Boolean = false
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Well-being & Distraction logs
        item {
            WellbeingDistractionLoggerCard(
                overview = overview,
                onUpdate = { viewModel.updateOverview(it) }
            )
        }

        // Habit Grid Checklist
        item {
            HabitTrackerChecklistGrid(
                selectedDate = selectedDate,
                habits = habits,
                onToggle = { viewModel.toggleHabit(it) },
                viewModel = viewModel
            )
        }

        // Error log / backlogs
        item {
            ErrorLogBacklogsSection(
                skippedTopics = skippedTopics,
                skippedQuestions = skippedQuestions,
                onAddSkippedTopicClick = onAddSkippedTopicClick,
                onAddSkippedQuestionClick = onAddSkippedQuestionClick,
                onUpdateTopic = { viewModel.updateSkippedTopic(it) },
                onDeleteTopic = { viewModel.deleteSkippedTopic(it) },
                onUpdateQuestion = { viewModel.updateSkippedQuestion(it) },
                onDeleteQuestion = { viewModel.deleteSkippedQuestion(it) }
            )
        }

        // Reflections cards
        item {
            ReflectionCardsSection(
                overview = overview,
                onUpdate = { viewModel.updateOverview(it) }
            )
        }
    }
}

// ==========================================
// WIDGET COMPOSABLES
// ==========================================

@Composable
fun DailyOverviewHeaderCard(
    selectedDate: String,
    overview: DailyOverview,
    progressLabel: String,
    progressFraction: Float,
    viewModel: StudyTrackerViewModel
) {
    val context = LocalContext.current

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header Info Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Date Select Action Button
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable {
                            // Date dialog picker trigger
                            val cal = Calendar.getInstance()
                            val parts = selectedDate.split("-")
                            if (parts.size == 3) {
                                cal.set(Calendar.YEAR, parts[0].toInt())
                                cal.set(Calendar.MONTH, parts[1].toInt() - 1)
                                cal.set(Calendar.DAY_OF_MONTH, parts[2].toInt())
                            }
                            DatePickerDialog(
                                context,
                                { _, y, m, d ->
                                    val formatted = String.format(Locale.US, "%d-%02d-%02d", y, m + 1, d)
                                    viewModel.selectDate(formatted)
                                },
                                cal.get(Calendar.YEAR),
                                cal.get(Calendar.MONTH),
                                cal.get(Calendar.DAY_OF_MONTH)
                            ).show()
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.CalendarToday,
                            contentDescription = "Date Picker Trigger",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = selectedDate,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                    Text(
                        text = "Day: ${overview.dayName}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Previous/Next Day Action row
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { viewModel.selectAdjacentDate(-1) }) {
                        Icon(
                            imageVector = Icons.Rounded.ArrowBack,
                            contentDescription = "Previous Day",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    IconButton(onClick = { viewModel.selectAdjacentDate(1) }) {
                        Icon(
                            imageVector = Icons.Rounded.ArrowForward,
                            contentDescription = "Next Day",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
            Spacer(modifier = Modifier.height(12.dp))

            // Info Details Row (Editable total study hours, focus selector, day count)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Day Count Input
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        "DAY COUNT",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    OutlinedTextField(
                        value = if (overview.dayCount == 0) "" else overview.dayCount.toString(),
                        onValueChange = { input ->
                            val newVal = input.filter { it.isDigit() }.toIntOrNull() ?: 0
                            viewModel.updateOverview(overview.copy(dayCount = newVal))
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        textStyle = LocalTextStyle.current.copy(fontSize = 14.sp, fontFamily = FontFamily.Monospace),
                        colors = OutlinedTextFieldDefaults.colors(
                            unfocusedBorderColor = MaterialTheme.colorScheme.surfaceVariant,
                            focusedBorderColor = MaterialTheme.colorScheme.primary
                        ),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("day_count_input")
                    )
                }

                // Total Study Hours
                Column(modifier = Modifier.weight(1.2f)) {
                    Text(
                        "TOTAL STUDY HOURS",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.primary
                    )
                    OutlinedTextField(
                        value = if (overview.totalStudyHours == 0.0) "" else overview.totalStudyHours.toString(),
                        onValueChange = { input ->
                            val newVal = input.toDoubleOrNull() ?: 0.0
                            viewModel.updateOverview(overview.copy(totalStudyHours = newVal))
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        textStyle = LocalTextStyle.current.copy(fontSize = 14.sp, fontFamily = FontFamily.Monospace),
                        colors = OutlinedTextFieldDefaults.colors(
                            unfocusedBorderColor = MaterialTheme.colorScheme.surfaceVariant,
                            focusedBorderColor = MaterialTheme.colorScheme.primary
                        ),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("study_hours_input")
                    )
                }

                // Focus Level Stars
                Column(
                    modifier = Modifier.weight(1.8f),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "FOCUS LEVEL",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.tertiary,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        for (star in 1..5) {
                            Icon(
                                imageVector = if (star <= overview.focusLevel) Icons.Rounded.Star else Icons.Rounded.StarBorder,
                                contentDescription = "Focus level star $star",
                                tint = if (star <= overview.focusLevel) AccentGold else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier
                                    .size(24.dp)
                                    .clickable {
                                        viewModel.updateOverview(overview.copy(focusLevel = star))
                                    }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Completion Sub-details
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Rounded.CheckCircle,
                        contentDescription = "Completed Ratio Icon",
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Task Completion: $progressLabel (${(progressFraction * 100).toInt()}%)",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                if (overview.pomodoroCount > 0) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .background(
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                                RoundedCornerShape(12.dp)
                            )
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Schedule,
                            contentDescription = "Pomodoros completed today",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${overview.pomodoroCount} Session${if (overview.pomodoroCount > 1) "s" else ""}",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun RevisionAlarmCenterWidget(
    selectedDate: String,
    subjectTrackers: List<SubjectTracker>
) {
    // Computes countdown for each next revision date in subjects
    val revisionTasks = remember(subjectTrackers, selectedDate) {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        subjectTrackers.filter { it.nextRevDate.isNotEmpty() }.map { tracker ->
            val dayDiff: Long = try {
                val nextDate = sdf.parse(tracker.nextRevDate) ?: Date()
                val activeDate = sdf.parse(selectedDate) ?: Date()
                val diffMs = nextDate.time - activeDate.time
                diffMs / (1000 * 60 * 60 * 24)
            } catch (e: Exception) {
                999L
            }
            Triple(tracker, tracker.nextRevDate, dayDiff)
        }.sortedBy { it.third }
    }

    if (revisionTasks.isNotEmpty()) {
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Alarm,
                        contentDescription = "Alarm center",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        "Revision Alarm Center",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    revisionTasks.take(5).forEach { record ->
                        val tracker = record.first
                        val date = record.second
                        val diff = record.third

                        val statusColor = when {
                            diff < 0L -> AccentRed
                            diff == 0L -> MaterialTheme.colorScheme.primary
                            else -> MaterialTheme.colorScheme.secondary
                        }

                        val statusText = when {
                            diff < 0L -> "${-diff}d Overdue"
                            diff == 0L -> "Due Today!"
                            else -> "${diff}d Left"
                        }

                        Box(
                            modifier = Modifier
                                .border(
                                    1.dp,
                                    statusColor.copy(alpha = 0.3f),
                                    RoundedCornerShape(8.dp)
                                )
                                .background(
                                    statusColor.copy(alpha = 0.05f),
                                    RoundedCornerShape(8.dp)
                                )
                                .padding(horizontal = 8.dp, vertical = 6.dp)
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = tracker.subjectName,
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = statusText,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 11.sp,
                                    color = statusColor
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SubjectsTrackerTableCard(
    selectedDate: String,
    subjectTrackers: List<SubjectTracker>,
    onAddSubjectClick: () -> Unit,
    dueRevisions: List<SubjectTracker>,
    onUpdate: (SubjectTracker) -> Unit,
    onDelete: (SubjectTracker) -> Unit
) {
    val context = LocalContext.current

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Table Header Title + Trigger
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Core Execution Matrix",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )

                Button(
                    onClick = onAddSubjectClick,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                        contentColor = MaterialTheme.colorScheme.primary
                    ),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier.height(30.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Add,
                        contentDescription = "Add custom subject",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Subject", style = MaterialTheme.typography.labelSmall)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Traditional horizontal table layout with scrollbar container if screen is narrow
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
            ) {
                Column(modifier = Modifier.widthIn(min = 850.dp)) {
                    // Headings Row
                    Row(
                        modifier = Modifier
                            .background(
                                MaterialTheme.colorScheme.background,
                                RoundedCornerShape(6.dp)
                            )
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Cols
                        TableHeaderCell("Subject / Topic", 140.dp)
                        TableHeaderCell("Class", 60.dp)
                        TableHeaderCell("Lect.", 60.dp)
                        TableHeaderCell("Recall", 60.dp)
                        TableHeaderCell("Notes", 60.dp)
                        TableHeaderCell("Short", 60.dp)
                        TableHeaderCell("Rev.", 60.dp)
                        TableHeaderCell("Next Rev. Date", 110.dp)
                        TableHeaderCell("Q-Bank Stat", 120.dp)
                        TableHeaderCell("Spaced Repetition (R3-R60)", 130.dp)
                        TableHeaderCell("Actions", 50.dp)
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    if (subjectTrackers.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "No subjects added for today. Tap Add Subject above to start.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        subjectTrackers.forEach { tracker ->
                            val isDueToday = dueRevisions.any { it.id == tracker.id }

                            // Highlighting Pulse Animation for Due Subjects
                            val infiniteTransition = rememberInfiniteTransition(label = "Pulse")
                            val pulseAlpha by infiniteTransition.animateFloat(
                                initialValue = 0.05f,
                                targetValue = 0.25f,
                                animationSpec = infiniteRepeatable(
                                    animation = twistTween(600, easing = LinearEasing),
                                    repeatMode = RepeatMode.Reverse
                                ),
                                label = "PulseAlpha"
                            )

                            Row(
                                modifier = Modifier
                                    .padding(vertical = 4.dp)
                                    .background(
                                        if (isDueToday) MaterialTheme.colorScheme.primary.copy(alpha = pulseAlpha)
                                        else Color.Transparent,
                                        RoundedCornerShape(6.dp)
                                    )
                                    .border(
                                        1.dp,
                                        if (isDueToday) MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
                                        else MaterialTheme.colorScheme.surfaceVariant,
                                        RoundedCornerShape(6.dp)
                                    )
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Subject Name Name display
                                Box(modifier = Modifier.width(140.dp)) {
                                    Text(
                                        text = tracker.subjectName,
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                // Class Checkbox
                                Box(modifier = Modifier.width(60.dp), contentAlignment = Alignment.Center) {
                                    CustomCheckbox(
                                        checked = tracker.isClass,
                                        onCheckedChange = { onUpdate(tracker.copy(isClass = it)) },
                                        color = AccentBlue
                                    )
                                }

                                // Lecture Checkbox
                                Box(modifier = Modifier.width(60.dp), contentAlignment = Alignment.Center) {
                                    CustomCheckbox(
                                        checked = tracker.isLecture,
                                        onCheckedChange = { onUpdate(tracker.copy(isLecture = it)) },
                                        color = AccentBlue
                                    )
                                }

                                // Active Recall Checkbox
                                Box(modifier = Modifier.width(60.dp), contentAlignment = Alignment.Center) {
                                    CustomCheckbox(
                                        checked = tracker.isActiveRecall,
                                        onCheckedChange = { onUpdate(tracker.copy(isActiveRecall = it)) },
                                        color = MaterialTheme.colorScheme.tertiary
                                    )
                                }

                                // Notes Checkbox
                                Box(modifier = Modifier.width(60.dp), contentAlignment = Alignment.Center) {
                                    CustomCheckbox(
                                        checked = tracker.isNotes,
                                        onCheckedChange = { onUpdate(tracker.copy(isNotes = it)) },
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                }

                                // Short Notes Checkbox
                                Box(modifier = Modifier.width(60.dp), contentAlignment = Alignment.Center) {
                                    CustomCheckbox(
                                        checked = tracker.isShortNotes,
                                        onCheckedChange = { onUpdate(tracker.copy(isShortNotes = it)) },
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                }

                                // Revision Checkbox
                                Box(modifier = Modifier.width(60.dp), contentAlignment = Alignment.Center) {
                                    CustomCheckbox(
                                        checked = tracker.isRevision,
                                        onCheckedChange = { onUpdate(tracker.copy(isRevision = it)) },
                                        color = AccentGold
                                    )
                                }

                                // Next Revision Date (Date Picker)
                                Box(modifier = Modifier.width(110.dp), contentAlignment = Alignment.Center) {
                                    val dateDisplay = tracker.nextRevDate.ifEmpty { "Set Date" }
                                    Box(
                                        modifier = Modifier
                                            .border(
                                                1.dp,
                                                MaterialTheme.colorScheme.surfaceVariant,
                                                RoundedCornerShape(6.dp)
                                            )
                                            .clickable {
                                                val cal = Calendar.getInstance()
                                                DatePickerDialog(
                                                    context,
                                                    { _, y, m, d ->
                                                        val formatted = String.format(
                                                            Locale.US,
                                                            "%d-%02d-%02d",
                                                            y,
                                                            m + 1,
                                                            d
                                                        )
                                                        onUpdate(tracker.copy(nextRevDate = formatted))
                                                    },
                                                    cal.get(Calendar.YEAR),
                                                    cal.get(Calendar.MONTH),
                                                    cal.get(Calendar.DAY_OF_MONTH)
                                                ).show()
                                            }
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = dateDisplay,
                                            style = MaterialTheme.typography.bodySmall,
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 11.sp,
                                            color = if (tracker.nextRevDate.isEmpty()) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }

                                // Dynamic Q-Bank Tracker Cell
                                Box(modifier = Modifier.width(120.dp)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        // Edit input field sizes
                                        NumericMiniBox(
                                            value = tracker.correct,
                                            label = "C",
                                            color = AccentGreen,
                                            onUpdate = { onUpdate(tracker.copy(correct = it)) }
                                        )
                                        NumericMiniBox(
                                            value = tracker.incorrect,
                                            label = "W",
                                            color = AccentRed,
                                            onUpdate = { onUpdate(tracker.copy(incorrect = it)) }
                                        )

                                        // Auto accuracy badge
                                        val totalQs = tracker.correct + tracker.incorrect
                                        if (totalQs > 0) {
                                            val accuracy = (tracker.correct.toFloat() / totalQs) * 100
                                            val badgeColor = when {
                                                accuracy >= 80f -> AccentGreen
                                                accuracy < 50f -> AccentRed
                                                else -> AccentGold
                                            }
                                            Box(
                                                modifier = Modifier
                                                    .background(
                                                        badgeColor.copy(alpha = 0.15f),
                                                        RoundedCornerShape(4.dp)
                                                    )
                                                    .border(
                                                        1.dp,
                                                        badgeColor.copy(alpha = 0.4f),
                                                        RoundedCornerShape(4.dp)
                                                    )
                                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                                            ) {
                                                Text(
                                                    text = "${accuracy.toInt()}%",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 10.sp,
                                                    color = badgeColor
                                                )
                                            }
                                        }
                                    }
                                }

                                // Spaced Repetition Rings R3 -> R60
                                Box(modifier = Modifier.width(130.dp), contentAlignment = Alignment.Center) {
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        SpacedRingToggle(
                                            label = "R3",
                                            checked = tracker.r3,
                                            onCheckedChange = { onUpdate(tracker.copy(r3 = it)) }
                                        )
                                        SpacedRingToggle(
                                            label = "R7",
                                            checked = tracker.r7,
                                            onCheckedChange = { onUpdate(tracker.copy(r7 = it)) }
                                        )
                                        SpacedRingToggle(
                                            label = "R15",
                                            checked = tracker.r15,
                                            onCheckedChange = { onUpdate(tracker.copy(r15 = it)) }
                                        )
                                        SpacedRingToggle(
                                            label = "R30",
                                            checked = tracker.r30,
                                            onCheckedChange = { onUpdate(tracker.copy(r30 = it)) }
                                        )
                                        SpacedRingToggle(
                                            label = "R60",
                                            checked = tracker.r60,
                                            onCheckedChange = { onUpdate(tracker.copy(r60 = it)) }
                                        )
                                    }
                                }

                                // Actions (Delete)
                                Box(modifier = Modifier.width(50.dp), contentAlignment = Alignment.Center) {
                                    IconButton(
                                        onClick = { onDelete(tracker) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Delete,
                                            contentDescription = "Delete subject",
                                            tint = AccentRed.copy(alpha = 0.7f),
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TableHeaderCell(text: String, width: Dp) {
    Box(
        modifier = Modifier.width(width),
        contentAlignment = Alignment.CenterStart
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun CustomCheckbox(checked: Boolean, onCheckedChange: (Boolean) -> Unit, color: Color) {
    Box(
        modifier = Modifier
            .size(22.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(if (checked) color.copy(alpha = 0.2f) else Color.Transparent)
            .border(
                1.5.dp,
                if (checked) color else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                RoundedCornerShape(4.dp)
            )
            .clickable { onCheckedChange(!checked) },
        contentAlignment = Alignment.Center
    ) {
        if (checked) {
            Icon(
                imageVector = Icons.Rounded.Check,
                contentDescription = "Checked",
                tint = color,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

@Composable
fun NumericMiniBox(value: Int, label: String, color: Color, onUpdate: (Int) -> Unit) {
    Box(
        modifier = Modifier
            .width(42.dp)
            .height(34.dp)
    ) {
        OutlinedTextField(
            value = if (value == 0) "" else value.toString(),
            onValueChange = { input ->
                val intVal = input.filter { it.isDigit() }.toIntOrNull() ?: 0
                onUpdate(intVal)
            },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            textStyle = LocalTextStyle.current.copy(
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            ),
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedBorderColor = MaterialTheme.colorScheme.surfaceVariant,
                focusedBorderColor = color
            ),
            singleLine = true,
            placeholder = {
                Text(
                    label,
                    style = MaterialTheme.typography.bodySmall,
                    fontSize = 11.sp,
                    textAlign = TextAlign.Center,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                )
            },
            modifier = Modifier.fillMaxSize()
        )
    }
}

@Composable
fun SpacedRingToggle(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    val ringColor = when (label) {
        "R3" -> MaterialTheme.colorScheme.primary
        "R7" -> MaterialTheme.colorScheme.secondary
        "R15" -> MaterialTheme.colorScheme.tertiary
        "R30" -> AccentGold
        else -> AccentOrange
    }

    Box(
        modifier = Modifier
            .size(18.dp)
            .clip(CircleShape)
            .background(if (checked) ringColor else Color.Transparent)
            .border(1.5.dp, ringColor, CircleShape)
            .clickable { onCheckedChange(!checked) },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label.replace("R", ""),
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Bold,
            fontSize = 8.sp,
            color = if (checked) Color.White else ringColor
        )
    }
}

// ==========================================
// TO-DO LIST AND TIME LOGGER SIDE BY SIDE
// ==========================================
@Composable
fun ToDoAndLoggerSection(
    todoItems: List<TodoItem>,
    timeSlots: List<TimeSlot>,
    onAddTodoClick: () -> Unit,
    onAddTimeSlotClick: () -> Unit,
    onToggleTodo: (TodoItem) -> Unit,
    onDeleteTodo: (Int) -> Unit,
    onDeleteTimeSlot: (Int) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Left Column: Interactive To-Do List
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant),
            modifier = Modifier
                .weight(1f)
                .heightIn(min = 220.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.ListAlt,
                            contentDescription = "Todo icon",
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "To-Do execution",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }

                    IconButton(onClick = onAddTodoClick, modifier = Modifier.size(24.dp)) {
                        Icon(
                            imageVector = Icons.Rounded.Add,
                            contentDescription = "Add Todo List Item",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                if (todoItems.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "No tasks listed. Good habits start here!",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        todoItems.forEach { item ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(
                                        MaterialTheme.colorScheme.background.copy(alpha = 0.5f),
                                        RoundedCornerShape(6.dp)
                                    )
                                    .border(
                                        1.dp,
                                        MaterialTheme.colorScheme.surfaceVariant,
                                        RoundedCornerShape(6.dp)
                                    )
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    modifier = Modifier.weight(1f),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    CustomCheckbox(
                                        checked = item.isCompleted,
                                        onCheckedChange = { onToggleTodo(item) },
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = item.title,
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            textDecoration = if (item.isCompleted) androidx.compose.ui.text.style.TextDecoration.LineThrough else null
                                        ),
                                        color = if (item.isCompleted) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onBackground,
                                        overflow = TextOverflow.Ellipsis,
                                        maxLines = 2
                                    )
                                }

                                IconButton(
                                    onClick = { onDeleteTodo(item.id) },
                                    modifier = Modifier.size(20.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Close,
                                        contentDescription = "Delete Item",
                                        tint = AccentRed.copy(alpha = 0.7f),
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Right Column: Time Tracker logger
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant),
            modifier = Modifier
                .weight(1.1f)
                .heightIn(min = 220.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.Timelapse,
                            contentDescription = "Time Track icon",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Time Execution Logger",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }

                    IconButton(onClick = onAddTimeSlotClick, modifier = Modifier.size(24.dp)) {
                        Icon(
                            imageVector = Icons.Rounded.Add,
                            contentDescription = "Add Time Slot",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                if (timeSlots.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "Time logger empty. Record your slots here.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        timeSlots.forEach { slot ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(
                                        MaterialTheme.colorScheme.background.copy(alpha = 0.5f),
                                        RoundedCornerShape(6.dp)
                                    )
                                    .border(
                                        1.dp,
                                        MaterialTheme.colorScheme.surfaceVariant,
                                        RoundedCornerShape(6.dp)
                                    )
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    modifier = Modifier.weight(1f),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .background(
                                                MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                                                RoundedCornerShape(4.dp)
                                            )
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = slot.time,
                                            style = MaterialTheme.typography.bodySmall,
                                            fontWeight = FontWeight.Bold,
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(8.dp))

                                    Text(
                                        text = slot.whatWasDone,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onBackground,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                IconButton(
                                    onClick = { onDeleteTimeSlot(slot.id) },
                                    modifier = Modifier.size(20.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Close,
                                        contentDescription = "Delete time slot",
                                        tint = AccentRed.copy(alpha = 0.7f),
                                        modifier = Modifier.size(13.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// Performance Insights rating footer box
@Composable
fun PerformanceRatingInsightsFooter(
    subjectTrackers: List<SubjectTracker>,
    progressFraction: Float
) {
    val totalWrong = subjectTrackers.sumOf { it.incorrect }
    val totalCorrect = subjectTrackers.sumOf { it.correct }

    val insightText = remember(totalWrong, totalCorrect, progressFraction) {
        when {
            totalWrong > 5 -> "Focus shift needed: Convert wrong answers into flashcards before sleeping."
            progressFraction >= 0.8f -> "Masterclass day: Excellent discipline. Read through notes briefly and rest well!"
            totalCorrect + totalWrong > 0 && totalCorrect.toFloat() / (totalCorrect + totalWrong) >= 0.8f -> "Superb accuracy today! Keep pushing with Active Recall."
            else -> "Active learning in progress. Use spaced repetition rings R3/R7 to cement today's topics."
        }
    }

    val themeColor = when {
        totalWrong > 5 -> AccentRed
        progressFraction >= 0.8f -> AccentGreen
        else -> MaterialTheme.colorScheme.primary
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                themeColor.copy(alpha = 0.3f),
                RoundedCornerShape(8.dp)
            )
            .background(
                themeColor.copy(alpha = 0.05f),
                RoundedCornerShape(8.dp)
            )
            .padding(12.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = Icons.Rounded.Lightbulb,
                contentDescription = "Insight Icon",
                tint = themeColor,
                modifier = Modifier.size(20.dp)
            )
            Column {
                Text(
                    text = "Daily Performance Insights",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = insightText,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

// Wellbeing & Distraction Logger
@Composable
fun WellbeingDistractionLoggerCard(
    overview: DailyOverview,
    onUpdate: (DailyOverview) -> Unit
) {
    val screenTimeLimitOvershot = overview.actualScreenTime > overview.targetScreenTime

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Rounded.PhoneAndroid,
                    contentDescription = "Digital Wellbeing",
                    tint = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Digital Wellbeing & Distractions",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Limit comparison
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        "TARGET SCREEN TIME",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.primary
                    )
                    OutlinedTextField(
                        value = if (overview.targetScreenTime == 0.0) "" else overview.targetScreenTime.toString(),
                        onValueChange = { input ->
                            val value = input.toDoubleOrNull() ?: 0.0
                            onUpdate(overview.copy(targetScreenTime = value))
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        textStyle = LocalTextStyle.current.copy(fontSize = 14.sp, fontFamily = FontFamily.Monospace),
                        trailingIcon = { Text("hrs", style = MaterialTheme.typography.bodySmall) },
                        colors = OutlinedTextFieldDefaults.colors(
                            unfocusedBorderColor = MaterialTheme.colorScheme.surfaceVariant,
                            focusedBorderColor = MaterialTheme.colorScheme.primary
                        ),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    )
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        "ACTUAL SCREEN TIME",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = if (screenTimeLimitOvershot) AccentRed else MaterialTheme.colorScheme.secondary
                    )
                    OutlinedTextField(
                        value = if (overview.actualScreenTime == 0.0) "" else overview.actualScreenTime.toString(),
                        onValueChange = { input ->
                            val value = input.toDoubleOrNull() ?: 0.0
                            onUpdate(overview.copy(actualScreenTime = value))
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        textStyle = LocalTextStyle.current.copy(fontSize = 14.sp, fontFamily = FontFamily.Monospace),
                        trailingIcon = { Text("hrs", style = MaterialTheme.typography.bodySmall) },
                        colors = OutlinedTextFieldDefaults.colors(
                            unfocusedBorderColor = if (screenTimeLimitOvershot) AccentRed else MaterialTheme.colorScheme.surfaceVariant,
                            focusedBorderColor = if (screenTimeLimitOvershot) AccentRed else MaterialTheme.colorScheme.primary
                        ),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    )
                }
            }

            if (screenTimeLimitOvershot) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(AccentRed.copy(alpha = 0.12f), RoundedCornerShape(6.dp))
                        .padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Warning,
                        contentDescription = "Overshoot alert",
                        tint = AccentRed,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Warning: Screentime limit overshot by ${(overview.actualScreenTime - overview.targetScreenTime).toFloat()} hours today!",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        color = AccentRed
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Main distraction triggers / intervention
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Column {
                    Text(
                        "MAIN DISTRACTION TRIGGER",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = overview.distractionTrigger,
                        onValueChange = { onUpdate(overview.copy(distractionTrigger = it)) },
                        placeholder = { Text("e.g. YouTube shorts loop, Slack notifications", fontSize = 12.sp) },
                        textStyle = LocalTextStyle.current.copy(fontSize = 13.sp),
                        colors = OutlinedTextFieldDefaults.colors(
                            unfocusedBorderColor = MaterialTheme.colorScheme.surfaceVariant,
                            focusedBorderColor = MaterialTheme.colorScheme.primary
                        ),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    )
                }

                Column {
                    Text(
                        "INTERVENTION STRATEGY",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = overview.interventionStrategy,
                        onValueChange = { onUpdate(overview.copy(interventionStrategy = it)) },
                        placeholder = { Text("e.g. Turn phone off, block tabs using browser blocker", fontSize = 12.sp) },
                        textStyle = LocalTextStyle.current.copy(fontSize = 13.sp),
                        colors = OutlinedTextFieldDefaults.colors(
                            unfocusedBorderColor = MaterialTheme.colorScheme.surfaceVariant,
                            focusedBorderColor = MaterialTheme.colorScheme.primary
                        ),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    )
                }
            }
        }
    }
}

// Habits Checklist Grid (Monday to Sunday)
@Composable
fun HabitTrackerChecklistGrid(
    selectedDate: String,
    habits: List<WeekHabit>,
    onToggle: (WeekHabit) -> Unit,
    viewModel: StudyTrackerViewModel
) {
    val habitsList = listOf("Wake Early", "Morning Warm Water", "Exercise", "Current Topic", "Revision")
    val daysOfWeekLabel = listOf("M", "T", "W", "T", "F", "S", "S")

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Rounded.VerifiedUser,
                    contentDescription = "Habit check status",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Weekly Habit Matrix",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                "Grid tracked Mon to Sun for the active week.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Habit visual grid
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                // Mon-Sun Days label row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(modifier = Modifier.width(130.dp)) // margin placeholder
                    Row(
                        modifier = Modifier.weight(1f),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        daysOfWeekLabel.forEach { label ->
                            Text(
                                text = label,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.width(24.dp),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                // Row for each pre-populated habit
                habitsList.forEach { habitName ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Habit Name Display
                        Text(
                            text = habitName,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onBackground,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.width(130.dp)
                        )

                        // Habit checkboxes from Mon to Sun
                        Row(
                            modifier = Modifier.weight(1f),
                            horizontalArrangement = Arrangement.SpaceAround
                        ) {
                            for (day in 1..7) {
                                val matchHabit = habits.find { it.dayOfWeek == day && it.habitName == habitName }

                                if (matchHabit != null) {
                                    Box(
                                        modifier = Modifier
                                            .size(24.dp)
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(
                                                if (matchHabit.isCompleted) MaterialTheme.colorScheme.secondary.copy(
                                                    alpha = 0.2f
                                                ) else Color.Transparent
                                            )
                                            .border(
                                                1.5.dp,
                                                if (matchHabit.isCompleted) MaterialTheme.colorScheme.secondary
                                                else MaterialTheme.colorScheme.onSurfaceVariant.copy(
                                                    alpha = 0.3f
                                                ),
                                                RoundedCornerShape(4.dp)
                                            )
                                            .clickable { onToggle(matchHabit) },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (matchHabit.isCompleted) {
                                            Icon(
                                                imageVector = Icons.Rounded.Check,
                                                contentDescription = "Completed habit",
                                                tint = MaterialTheme.colorScheme.secondary,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                } else {
                                    // Placeholder
                                    Box(modifier = Modifier.size(24.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// Error Logs & Backlogs
@Composable
fun ErrorLogBacklogsSection(
    skippedTopics: List<SkippedTopic>,
    skippedQuestions: List<SkippedQuestion>,
    onAddSkippedTopicClick: () -> Unit,
    onAddSkippedQuestionClick: () -> Unit,
    onUpdateTopic: (SkippedTopic) -> Unit,
    onDeleteTopic: (Int) -> Unit,
    onUpdateQuestion: (SkippedQuestion) -> Unit,
    onDeleteQuestion: (Int) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        // Skipped/Pending Topics Tracker
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.PlaylistRemove,
                            contentDescription = "Skipped items",
                            tint = AccentGold,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Pending & Skipped Topics Backlog",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }

                    IconButton(onClick = onAddSkippedTopicClick, modifier = Modifier.size(24.dp)) {
                        Icon(
                            imageVector = Icons.Rounded.Add,
                            contentDescription = "Add skipped topic row",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                if (skippedTopics.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "Clean logs! No pending topics backlog recorded.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        skippedTopics.forEach { record ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(
                                        MaterialTheme.colorScheme.background.copy(alpha = 0.5f),
                                        RoundedCornerShape(6.dp)
                                    )
                                    .border(
                                        1.dp,
                                        MaterialTheme.colorScheme.surfaceVariant,
                                        RoundedCornerShape(6.dp)
                                    )
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${record.subject}: ${record.topic}",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onBackground
                                    )
                                    if (record.plannedDate.isNotEmpty()) {
                                        Text(
                                            text = "Plan Date: ${record.plannedDate}",
                                            style = MaterialTheme.typography.bodySmall,
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    // Status drop cycle button (Pending / Scheduled / Done)
                                    val statusColor = when (record.status) {
                                        "Done" -> AccentGreen
                                        "Scheduled" -> AccentOrange
                                        else -> AccentRed
                                    }

                                    Box(
                                        modifier = Modifier
                                            .background(
                                                statusColor.copy(alpha = 0.15f),
                                                RoundedCornerShape(4.dp)
                                            )
                                            .border(
                                                1.dp,
                                                statusColor.copy(alpha = 0.4f),
                                                RoundedCornerShape(4.dp)
                                            )
                                            .clickable {
                                                val nextStatus = when (record.status) {
                                                    "Pending" -> "Scheduled"
                                                    "Scheduled" -> "Done"
                                                    else -> "Pending"
                                                }
                                                onUpdateTopic(record.copy(status = nextStatus))
                                            }
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            text = record.status,
                                            style = MaterialTheme.typography.bodySmall,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = statusColor
                                        )
                                    }

                                    IconButton(
                                        onClick = { onDeleteTopic(record.id) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Close,
                                            contentDescription = "Delete topic",
                                            tint = AccentRed.copy(alpha = 0.7f),
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Skipped Questions Tracker (Error journal)
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Rounded.ErrorOutline,
                            contentDescription = "Incorrect Q bank icon",
                            tint = AccentRed,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Skipped Questions Journal",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }

                    IconButton(onClick = onAddSkippedQuestionClick, modifier = Modifier.size(24.dp)) {
                        Icon(
                            imageVector = Icons.Rounded.Add,
                            contentDescription = "Add question record",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                if (skippedQuestions.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "Accuracy 100%! No skipped questions log.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        skippedQuestions.forEach { record ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(
                                        MaterialTheme.colorScheme.background.copy(alpha = 0.5f),
                                        RoundedCornerShape(6.dp)
                                    )
                                    .border(
                                        1.dp,
                                        MaterialTheme.colorScheme.surfaceVariant,
                                        RoundedCornerShape(6.dp)
                                    )
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    CustomCheckbox(
                                        checked = record.isDone,
                                        onCheckedChange = { onUpdateQuestion(record.copy(isDone = it)) },
                                        color = MaterialTheme.colorScheme.secondary
                                    )

                                    Spacer(modifier = Modifier.width(8.dp))

                                    Column {
                                        Text(
                                            text = "${record.subject}: Q ${record.qNo}",
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                textDecoration = if (record.isDone) androidx.compose.ui.text.style.TextDecoration.LineThrough else null
                                            ),
                                            fontWeight = FontWeight.Bold,
                                            color = if (record.isDone) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onBackground
                                        )
                                        Text(
                                            text = "${record.topic} | Reattempt: ${record.reattemptDate}",
                                            style = MaterialTheme.typography.bodySmall,
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                IconButton(
                                    onClick = { onDeleteQuestion(record.id) },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Rounded.Close,
                                        contentDescription = "Delete record",
                                        tint = AccentRed.copy(alpha = 0.7f),
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// Reflection Cards (Happy today / Best / Worst)
@Composable
fun ReflectionCardsSection(
    overview: DailyOverview,
    onUpdate: (DailyOverview) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Rounded.SelfImprovement,
                    contentDescription = "Reflect icons",
                    tint = MaterialTheme.colorScheme.tertiary,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Daily Journal & Evaluation",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Happy today box
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Column {
                    Text(
                        "🚨 WHAT ROADBLOCKS DID I FACE?",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = AccentRed
                    )
                    OutlinedTextField(
                        value = overview.happyToday,
                        onValueChange = { onUpdate(overview.copy(happyToday = it)) },
                        placeholder = { Text("List any blockers or focus sidetracks...", fontSize = 12.sp) },
                        colors = OutlinedTextFieldDefaults.colors(
                            unfocusedBorderColor = MaterialTheme.colorScheme.surfaceVariant,
                            focusedBorderColor = MaterialTheme.colorScheme.primary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(60.dp)
                    )
                }

                Column {
                    Text(
                        "🌟 BEST LEARNINGS / BREAKTHROUGHS",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    OutlinedTextField(
                        value = overview.bestThingsToday,
                        onValueChange = { onUpdate(overview.copy(bestThingsToday = it)) },
                        placeholder = { Text("Add topics, equations, or concepts conquered...", fontSize = 12.sp) },
                        colors = OutlinedTextFieldDefaults.colors(
                            unfocusedBorderColor = MaterialTheme.colorScheme.surfaceVariant,
                            focusedBorderColor = MaterialTheme.colorScheme.primary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(60.dp)
                    )
                }

                Column {
                    Text(
                        "🧠 HOW COMPLETED IS REVISION SCHEDULE?",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.tertiary
                    )
                    OutlinedTextField(
                        value = overview.worstThingsToday,
                        onValueChange = { onUpdate(overview.copy(worstThingsToday = it)) },
                        placeholder = { Text("Record any spaced repetitions that need rescheduling...", fontSize = 12.sp) },
                        colors = OutlinedTextFieldDefaults.colors(
                            unfocusedBorderColor = MaterialTheme.colorScheme.surfaceVariant,
                            focusedBorderColor = MaterialTheme.colorScheme.primary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(60.dp)
                    )
                }
            }
        }
    }
}

// Floating Pomodoro timer widget (start/pause animations)
@Composable
fun FloatingPomodoroWidget(
    secondsLeft: Int,
    isRunning: Boolean,
    mode: String,
    onToggle: () -> Unit,
    onReset: () -> Unit,
    onSetMode: (String) -> Unit,
    pomodoroCount: Int
) {
    var expanded by remember { mutableStateOf(false) }

    val formattedTime = remember(secondsLeft) {
        val mins = secondsLeft / 60
        val secs = secondsLeft % 60
        String.format(Locale.US, "%02d:%02d", mins, secs)
    }

    Box(
        modifier = Modifier
            .padding(16.dp),
        contentAlignment = Alignment.BottomEnd
    ) {
        Column(
            horizontalAlignment = Alignment.End,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Expanded controls panel popup
            AnimatedVisibility(
                visible = expanded,
                enter = fadeIn() + expandVertically(expandFrom = Alignment.Bottom),
                exit = fadeOut() + shrinkVertically(shrinkTowards = Alignment.Bottom)
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .width(220.dp)
                        .shadow(12.dp, RoundedCornerShape(16.dp))
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = if (mode == "Work") "⏱️ WORK FOCUS" else "☕ BREAK TIME",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (mode == "Work") AccentRed else MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )

                        // Mins visual counter displays
                        Text(
                            text = formattedTime,
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace,
                            color = MaterialTheme.colorScheme.onBackground
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Controls
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Button(
                                onClick = onToggle,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isRunning) AccentGold else MaterialTheme.colorScheme.primary
                                ),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                modifier = Modifier.height(32.dp)
                            ) {
                                Icon(
                                    imageVector = if (isRunning) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                    contentDescription = "Toggle",
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    if (isRunning) "Pause" else "Focus",
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }

                            OutlinedButton(
                                onClick = onReset,
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp),
                                modifier = Modifier.height(32.dp)
                            ) {
                                Text("Reset", style = MaterialTheme.typography.labelSmall)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
                        Spacer(modifier = Modifier.height(8.dp))

                        // Modes toggles
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            // Work switch
                            Box(
                                modifier = Modifier
                                    .background(
                                        if (mode == "Work") AccentRed.copy(alpha = 0.12f) else Color.Transparent,
                                        RoundedCornerShape(6.dp)
                                    )
                                    .border(
                                        1.dp,
                                        if (mode == "Work") AccentRed else MaterialTheme.colorScheme.surfaceVariant,
                                        RoundedCornerShape(6.dp)
                                    )
                                    .clickable { onSetMode("Work") }
                                    .padding(vertical = 4.dp, horizontal = 10.dp)
                            ) {
                                Text(
                                    "Work",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (mode == "Work") AccentRed else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            // Break toggle
                            Box(
                                modifier = Modifier
                                    .background(
                                        if (mode == "Break") MaterialTheme.colorScheme.secondary.copy(
                                            alpha = 0.12f
                                        ) else Color.Transparent,
                                        RoundedCornerShape(6.dp)
                                    )
                                    .border(
                                        1.dp,
                                        if (mode == "Break") MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.surfaceVariant,
                                        RoundedCornerShape(6.dp)
                                    )
                                    .clickable { onSetMode("Break") }
                                    .padding(vertical = 4.dp, horizontal = 10.dp)
                            ) {
                                Text(
                                    "Break",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (mode == "Break") MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        if (pomodoroCount > 0) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                "Total: $pomodoroCount round${if (pomodoroCount > 1) "s" else ""} done",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }

            // Floating main widget trigger button
            FloatingActionButton(
                onClick = { expanded = !expanded },
                containerColor = if (isRunning) AccentRed else MaterialTheme.colorScheme.primary,
                contentColor = Color.White,
                shape = CircleShape,
                modifier = Modifier
                    .size(60.dp)
                    .testTag("floating_pomodoro_fab")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = if (expanded) Icons.Rounded.KeyboardArrowDown else Icons.Rounded.HourglassBottom,
                        contentDescription = "Expand Pomodoro Widget",
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }
    }
}



// ==========================================
// FORM DIALOGS
// ==========================================

@Composable
fun AddSubjectDialog(
    onDismiss: () -> Unit,
    onAdd: (String) -> Unit
) {
    var text by remember { mutableStateOf("") }
    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    "Add Custom Subject Row",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    placeholder = { Text("e.g. Microbiology, Pathology") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        unfocusedBorderColor = MaterialTheme.colorScheme.surfaceVariant,
                        focusedBorderColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Button(onClick = { onAdd(text) }) { Text("Add Row") }
                }
            }
        }
    }
}

@Composable
fun AddTodoDialog(
    onDismiss: () -> Unit,
    onAdd: (String) -> Unit
) {
    var text by remember { mutableStateOf("") }
    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    "Add new execution todo",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    placeholder = { Text("e.g. Solve biochem error cards, read page 45 anatomy") },
                    colors = OutlinedTextFieldDefaults.colors(
                        unfocusedBorderColor = MaterialTheme.colorScheme.surfaceVariant,
                        focusedBorderColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Button(onClick = { onAdd(text) }) { Text("Create Task") }
                }
            }
        }
    }
}

@Composable
fun AddTimeSlotDialog(
    onDismiss: () -> Unit,
    onAdd: (String, String) -> Unit
) {
    var time by remember { mutableStateOf("") }
    var detail by remember { mutableStateOf("") }

    // Initialize with current time for easier logging
    LaunchedEffect(Unit) {
        val sdf = SimpleDateFormat("HH:mm", Locale.US)
        time = sdf.format(Date())
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    "Log active Study Time Slot",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                OutlinedTextField(
                    value = time,
                    onValueChange = { time = it },
                    label = { Text("Timestamp / Interval") },
                    colors = OutlinedTextFieldDefaults.colors(
                        unfocusedBorderColor = MaterialTheme.colorScheme.surfaceVariant,
                        focusedBorderColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = detail,
                    onValueChange = { detail = it },
                    label = { Text("What study was accomplished?") },
                    placeholder = { Text("e.g. Completed lecture physiology, 15 physics MCQ cards") },
                    colors = OutlinedTextFieldDefaults.colors(
                        unfocusedBorderColor = MaterialTheme.colorScheme.surfaceVariant,
                        focusedBorderColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Button(onClick = { onAdd(time, detail) }) { Text("Add Slot") }
                }
            }
        }
    }
}

@Composable
fun AddSkippedTopicDialog(
    onDismiss: () -> Unit,
    onAdd: (String, String, String) -> Unit
) {
    var subject by remember { mutableStateOf("") }
    var topic by remember { mutableStateOf("") }
    var date by remember { mutableStateOf("") }
    val context = LocalContext.current

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    "Backlog a Skipped Topic",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                OutlinedTextField(
                    value = subject,
                    onValueChange = { subject = it },
                    label = { Text("Subject (Anatomy, Physiology etc.)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        unfocusedBorderColor = MaterialTheme.colorScheme.surfaceVariant,
                        focusedBorderColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = topic,
                    onValueChange = { topic = it },
                    label = { Text("Skipped Topic Detail") },
                    colors = OutlinedTextFieldDefaults.colors(
                        unfocusedBorderColor = MaterialTheme.colorScheme.surfaceVariant,
                        focusedBorderColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                // Date selecting mock
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            1.dp,
                            MaterialTheme.colorScheme.surfaceVariant,
                            RoundedCornerShape(4.dp)
                        )
                        .clickable {
                            val cal = Calendar.getInstance()
                            DatePickerDialog(
                                context,
                                { _, y, m, d ->
                                    val formatted = String.format(Locale.US, "%d-%02d-%02d", y, m + 1, d)
                                    date = formatted
                                },
                                cal.get(Calendar.YEAR),
                                cal.get(Calendar.MONTH),
                                cal.get(Calendar.DAY_OF_MONTH)
                            ).show()
                        }
                        .padding(12.dp)
                ) {
                    Text(
                        text = if (date.isEmpty()) "Select Target Reattempt Date" else "Target Reattempt: $date",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (date.isEmpty()) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.primary
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Button(onClick = { onAdd(subject, topic, date) }) { Text("Save Backlog") }
                }
            }
        }
    }
}

@Composable
fun AddSkippedQuestionDialog(
    onDismiss: () -> Unit,
    onAdd: (String, String, String, String) -> Unit
) {
    var subject by remember { mutableStateOf("") }
    var topic by remember { mutableStateOf("") }
    var qNo by remember { mutableStateOf("") }
    var date by remember { mutableStateOf("") }
    val context = LocalContext.current

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.surfaceVariant),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    "Log Skipped Questions Record",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                OutlinedTextField(
                    value = subject,
                    onValueChange = { subject = it },
                    label = { Text("Subject") },
                    colors = OutlinedTextFieldDefaults.colors(
                        unfocusedBorderColor = MaterialTheme.colorScheme.surfaceVariant,
                        focusedBorderColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = topic,
                    onValueChange = { topic = it },
                    label = { Text("Topic Description") },
                    colors = OutlinedTextFieldDefaults.colors(
                        unfocusedBorderColor = MaterialTheme.colorScheme.surfaceVariant,
                        focusedBorderColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = qNo,
                    onValueChange = { qNo = it },
                    label = { Text("Question Details / No.") },
                    colors = OutlinedTextFieldDefaults.colors(
                        unfocusedBorderColor = MaterialTheme.colorScheme.surfaceVariant,
                        focusedBorderColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                // Date popup simple select
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            1.dp,
                            MaterialTheme.colorScheme.surfaceVariant,
                            RoundedCornerShape(4.dp)
                        )
                        .clickable {
                            val cal = Calendar.getInstance()
                            DatePickerDialog(
                                context,
                                { _, y, m, d ->
                                    val formatted = String.format(Locale.US, "%d-%02d-%02d", y, m + 1, d)
                                    date = formatted
                                },
                                cal.get(Calendar.YEAR),
                                cal.get(Calendar.MONTH),
                                cal.get(Calendar.DAY_OF_MONTH)
                            ).show()
                        }
                        .padding(12.dp)
                ) {
                    Text(
                        text = if (date.isEmpty()) "Select Reattempt Date" else "Reattempt target: $date",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (date.isEmpty()) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.primary
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Button(onClick = { onAdd(subject, topic, qNo, date) }) { Text("Save Record") }
                }
            }
        }
    }
}

// Custom Twinkle tween function matching user's twistTween behavior requirements
fun twistTween(durationMillis: Int = 300, delayMillis: Int = 0, easing: Easing = FastOutSlowInEasing): TweenSpec<Float> {
    return TweenSpec(durationMillis = durationMillis, delay = delayMillis, easing = easing)
}
