package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Mode Cohesion
val LightBackground = Color(0xFFF9FAFB)
val LightSurface = Color(0xFFFFFFFF)
val LightPrimary = Color(0xFF4F46E5) // Indigo
val LightSecondary = Color(0xFF0D9488) // Emerald
val LightTertiary = Color(0xFF7C3AED) // Violet
val LightTextPrimary = Color(0xFF111827)
val LightTextSecondary = Color(0xFF4B5563)
val LightCardBorder = Color(0xFFE5E7EB)

// Deep Space Slate Dark Mode
val DarkBackground = Color(0xFF090D16) // Deep Space Black Space Slate
val DarkSurface = Color(0xFF131A26) // Deep Slate Card Surface
val DarkPrimary = Color(0xFF6366F1) // Indigo/Violet
val DarkSecondary = Color(0xFF10B981) // Emerald Accent
val DarkTertiary = Color(0xFF8B5CF6) // Violet Accent
val DarkTextPrimary = Color(0xFFF3F4F6) // Light Gray
val DarkTextSecondary = Color(0xFF9CA3AF) // Muted slate gray
val DarkCardBorder = Color(0xFF1F293D) // Subtle dark borders

// Accent variations
val AccentGold = Color(0xFFFBBF24) // Focus stars
val AccentRed = Color(0xFFEF4444) // Incorrect/Overuse
val AccentGreen = Color(0xFF10B981) // Correct/Completed
val AccentBlue = Color(0xFF3B82F6) // Class/Lecture
val AccentOrange = Color(0xFFF97316) // Scheduled/Warning
