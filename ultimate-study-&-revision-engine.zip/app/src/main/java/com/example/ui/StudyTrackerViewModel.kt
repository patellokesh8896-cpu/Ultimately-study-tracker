package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class StudyTrackerViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application)
    private val repository = StudyRepository(database.studyDao())

    // --- State variables ---
    private val _selectedDate = MutableStateFlow(getTodayDateString())
    val selectedDate: StateFlow<String> = _selectedDate.asStateFlow()

    private val _isLandscapeLayout = MutableStateFlow(false)
    val isLandscapeLayout: StateFlow<Boolean> = _isLandscapeLayout.asStateFlow()

    private val _isDarkMode = MutableStateFlow(true)
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    // --- Zen Mode ---
    private val _isZenMode = MutableStateFlow(false)
    val isZenMode: StateFlow<Boolean> = _isZenMode.asStateFlow()

    // --- Custom Pomodoro timer inputs ---
    private val _customHours = MutableStateFlow(0)
    val customHours: StateFlow<Int> = _customHours.asStateFlow()

    private val _customMinutes = MutableStateFlow(25)
    val customMinutes: StateFlow<Int> = _customMinutes.asStateFlow()

    private val _customSeconds = MutableStateFlow(0)
    val customSeconds: StateFlow<Int> = _customSeconds.asStateFlow()

    private val _activeStudyTask = MutableStateFlow("Anatomy Study")
    val activeStudyTask: StateFlow<String> = _activeStudyTask.asStateFlow()

    // --- Pomodoro State ---
    private val _pomodoroSecondsLeft = MutableStateFlow(25 * 60)
    val pomodoroSecondsLeft: StateFlow<Int> = _pomodoroSecondsLeft.asStateFlow()

    private val _isPomodoroRunning = MutableStateFlow(false)
    val isPomodoroRunning: StateFlow<Boolean> = _isPomodoroRunning.asStateFlow()

    private val _pomodoroMode = MutableStateFlow("Work") // "Work" (25 mins) or "Break" (5 mins)
    val pomodoroMode: StateFlow<String> = _pomodoroMode.asStateFlow()

    private var pomodoroJob: Job? = null

    // --- Active Flows linked to current selectedDate ---
    val currentOverview: StateFlow<DailyOverview> = _selectedDate
        .flatMapLatest { date ->
            repository.getOverviewForDate(date)
                .onEach { overview ->
                    if (overview == null) {
                        viewModelScope.launch {
                            val emptyOverview = DailyOverview(
                                date = date,
                                dayName = getDayNameFromDate(date),
                                dayCount = 1
                            )
                            repository.insertOverview(emptyOverview)
                        }
                    }
                }
                .filterNotNull()
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = DailyOverview(getTodayDateString(), getDayNameFromDate(getTodayDateString()))
        )

    val currentSubjectTrackers: StateFlow<List<SubjectTracker>> = _selectedDate
        .flatMapLatest { date ->
            repository.getSubjectTrackersForDate(date)
                .onEach { list ->
                    if (list.isEmpty()) {
                        viewModelScope.launch {
                            val defaults = listOf(
                                "Anatomy", "Physiology", "Biochemistry",
                                "Psychology", "Sociology", "Biophysics"
                            )
                            defaults.forEach { sub ->
                                repository.insertSubjectTracker(
                                    SubjectTracker(date = date, subjectName = sub)
                                )
                            }
                        }
                    }
                }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val currentTodoItems: StateFlow<List<TodoItem>> = _selectedDate
        .flatMapLatest { date -> repository.getTodoItemsForDate(date) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val currentTimeSlots: StateFlow<List<TimeSlot>> = _selectedDate
        .flatMapLatest { date -> repository.getTimeSlotsForDate(date) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val currentHabits: StateFlow<List<WeekHabit>> = _selectedDate
        .flatMapLatest { date ->
            val monDate = getMondayOfWeek(date)
            repository.getHabitsForWeek(monDate)
                .onEach { list ->
                    val expectedHabitNames = listOf("Wake Early", "Morning Warm Water", "Exercise", "Current Topic", "Revision")
                    val existingCount = list.size
                    // We expect 5 habits * 7 days = 35 entries
                    if (existingCount < 35) {
                        viewModelScope.launch {
                            for (day in 1..7) {
                                for (habit in expectedHabitNames) {
                                    val exists = list.any { it.dayOfWeek == day && it.habitName == habit }
                                    if (!exists) {
                                        repository.insertWeekHabit(
                                            WeekHabit(
                                                weekStartDate = monDate,
                                                dayOfWeek = day,
                                                habitName = habit,
                                                isCompleted = false
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Global backlogs (global, not tied to single selected date, for better tracking)
    val skippedTopics: StateFlow<List<SkippedTopic>> = repository.getSkippedTopics()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val skippedQuestions: StateFlow<List<SkippedQuestion>> = repository.getSkippedQuestions()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // --- Constructor Initialization ---
    init {
        // Start Pomodoro updates check if active
    }

    // --- Navigation & Configurations ---
    fun selectDate(date: String) {
        _selectedDate.value = date
    }

    fun selectAdjacentDate(days: Int) {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        try {
            val date = sdf.parse(_selectedDate.value) ?: return
            val cal = Calendar.getInstance()
            cal.time = date
            cal.add(Calendar.DAY_OF_YEAR, days)
            _selectedDate.value = sdf.format(cal.time)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun toggleLayout() {
        _isLandscapeLayout.value = !_isLandscapeLayout.value
    }

    fun toggleTheme() {
        _isDarkMode.value = !_isDarkMode.value
    }

    fun toggleZenMode() {
        _isZenMode.value = !_isZenMode.value
    }

    fun setActiveStudyTask(task: String) {
        _activeStudyTask.value = task
    }

    // --- Database Operations ---

    // Daily Overview Update
    fun updateOverview(overview: DailyOverview) {
        viewModelScope.launch {
            repository.insertOverview(overview)
        }
    }

    // Subject Trackers
    fun addCustomSubject(name: String) {
        if (name.isBlank()) return
        viewModelScope.launch {
            repository.insertSubjectTracker(
                SubjectTracker(date = _selectedDate.value, subjectName = name)
            )
        }
    }

    fun updateSubjectTracker(tracker: SubjectTracker) {
        viewModelScope.launch {
            repository.updateSubjectTracker(tracker)
        }
    }

    fun deleteSubjectTracker(tracker: SubjectTracker) {
        viewModelScope.launch {
            repository.deleteSubjectTracker(tracker)
        }
    }

    // Todo List
    fun addTodoItem(title: String) {
        if (title.isBlank()) return
        viewModelScope.launch {
            repository.insertTodoItem(
                TodoItem(date = _selectedDate.value, title = title)
            )
        }
    }

    fun toggleTodoItem(item: TodoItem) {
        viewModelScope.launch {
            repository.updateTodoItem(item.copy(isCompleted = !item.isCompleted))
        }
    }

    fun deleteTodoItem(id: Int) {
        viewModelScope.launch {
            repository.deleteTodoItemById(id)
        }
    }

    // Time slots logger
    fun addTimeSlot(time: String, whatWasDone: String) {
        viewModelScope.launch {
            repository.insertTimeSlot(
                TimeSlot(date = _selectedDate.value, time = time, whatWasDone = whatWasDone)
            )
        }
    }

    fun deleteTimeSlot(id: Int) {
        viewModelScope.launch {
            repository.deleteTimeSlotById(id)
        }
    }

    // Habits checkbox interaction
    fun toggleHabit(weekHabit: WeekHabit) {
        viewModelScope.launch {
            repository.updateWeekHabit(weekHabit.copy(isCompleted = !weekHabit.isCompleted))
        }
    }

    // Skipped Topics (Backlog)
    fun addSkippedTopic(subject: String, topic: String, date: String) {
        if (subject.isBlank() || topic.isBlank()) return
        viewModelScope.launch {
            repository.insertSkippedTopic(
                SkippedTopic(subject = subject, topic = topic, plannedDate = date, status = "Pending")
            )
        }
    }

    fun updateSkippedTopic(topic: SkippedTopic) {
        viewModelScope.launch {
            repository.updateSkippedTopic(topic)
        }
    }

    fun deleteSkippedTopic(id: Int) {
        viewModelScope.launch {
            repository.deleteSkippedTopicById(id)
        }
    }

    // Skipped Questions (Backlog)
    fun addSkippedQuestion(subject: String, topic: String, qNo: String, reattemptDate: String) {
        if (subject.isBlank() || topic.isBlank() || qNo.isBlank()) return
        viewModelScope.launch {
            repository.insertSkippedQuestion(
                SkippedQuestion(subject = subject, topic = topic, qNo = qNo, reattemptDate = reattemptDate, isDone = false)
            )
        }
    }

    fun updateSkippedQuestion(question: SkippedQuestion) {
        viewModelScope.launch {
            repository.updateSkippedQuestion(question)
        }
    }

    fun deleteSkippedQuestion(id: Int) {
        viewModelScope.launch {
            repository.deleteSkippedQuestionById(id)
        }
    }

    // --- Pomodoro logic ---
    fun togglePomodoro() {
        if (_isPomodoroRunning.value) {
            pausePomodoro()
        } else {
            startPomodoro()
        }
    }

    fun resetPomodoro() {
        pausePomodoro()
        _pomodoroSecondsLeft.value = if (_pomodoroMode.value == "Work") {
            (_customHours.value * 3600) + (_customMinutes.value * 60) + _customSeconds.value
        } else {
            5 * 60
        }
    }

    fun setPomodoroMode(mode: String) {
        pausePomodoro()
        _pomodoroMode.value = mode
        _pomodoroSecondsLeft.value = if (mode == "Work") {
            (_customHours.value * 3600) + (_customMinutes.value * 60) + _customSeconds.value
        } else {
            5 * 60
        }
    }

    fun setCustomPomodoroTime(hours: Int, minutes: Int, seconds: Int) {
        pausePomodoro()
        _customHours.value = hours
        _customMinutes.value = minutes
        _customSeconds.value = seconds
        _pomodoroMode.value = "Work"
        _pomodoroSecondsLeft.value = (hours * 3600) + (minutes * 60) + seconds
    }

    private fun startPomodoro() {
        _isPomodoroRunning.value = true
        pomodoroJob?.cancel()
        pomodoroJob = viewModelScope.launch {
            while (_pomodoroSecondsLeft.value > 0) {
                delay(1000)
                _pomodoroSecondsLeft.value -= 1
            }
            // Pomodoro round finished!
            handlePomodoroFinished()
        }
    }

    private fun pausePomodoro() {
        _isPomodoroRunning.value = false
        pomodoroJob?.cancel()
    }

    private fun handlePomodoroFinished() {
        _isPomodoroRunning.value = false
        val currentMode = _pomodoroMode.value
        if (currentMode == "Work") {
            // Automatically increment the pomodoro count in currentOverview!
            viewModelScope.launch {
                val overview = currentOverview.value
                val updated = overview.copy(pomodoroCount = overview.pomodoroCount + 1)
                repository.insertOverview(updated)
            }
            // Switch mode to break
            _pomodoroMode.value = "Break"
            _pomodoroSecondsLeft.value = 5 * 60
        } else {
            // Switch mode to work
            _pomodoroMode.value = "Work"
            _pomodoroSecondsLeft.value = (_customHours.value * 3600) + (_customMinutes.value * 60) + _customSeconds.value
        }
    }

    // --- Static Utility Helpers ---
    private fun getTodayDateString(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        return sdf.format(Date())
    }

    fun getDayNameFromDate(dateStr: String): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        try {
            val date = sdf.parse(dateStr) ?: return ""
            val dayFormat = SimpleDateFormat("EEEE", Locale.US)
            return dayFormat.format(date)
        } catch (e: Exception) {
            return ""
        }
    }

    fun getMondayOfWeek(dateStr: String): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        try {
            val date = sdf.parse(dateStr) ?: return dateStr
            val cal = Calendar.getInstance()
            cal.time = date
            // Set first day of week to Monday
            cal.firstDayOfWeek = Calendar.MONDAY
            cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
            return sdf.format(cal.time)
        } catch (e: Exception) {
            return dateStr
        }
    }

    fun getDayOfLastWeek(dateStr: String, dayOffset: Int): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        try {
            val date = sdf.parse(dateStr) ?: return dateStr
            val cal = Calendar.getInstance()
            cal.time = date
            cal.add(Calendar.DAY_OF_YEAR, dayOffset)
            return sdf.format(cal.time)
        } catch (e: Exception) {
            return dateStr
        }
    }
}
